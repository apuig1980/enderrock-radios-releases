// Utilidades JS para la app (descarga de ficheros y gráficos ECharts).
window.enderrock = {
    descargar: function (nombre, base64, tipo) {
        const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
        const blob = new Blob([bytes], { type: tipo || 'application/octet-stream' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = nombre;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    },
    grafico: function (id, opciones) {
        const el = document.getElementById(id);
        if (!el || !window.echarts) return;
        let g = echarts.getInstanceByDom(el);
        if (!g) {
            g = echarts.init(el);
            new ResizeObserver(() => g.resize()).observe(el);
        }
        opciones.tooltip = opciones.tooltip || {};
        if (opciones.porcentaje) {
            opciones.tooltip.valueFormatter = v => v == null ? '–' : v.toFixed(1).replace('.', ',') + ' %';
            opciones.yAxis.axisLabel = { formatter: v => v + ' %' };
        }
        g.setOption(opciones, true);
    },
    copiar: function (texto) { return navigator.clipboard.writeText(texto); }
};

// Sube los CSV elegidos a la app local con barra de progreso (más rápido que por SignalR).
window.enderrock.subir = function (inputId, dotnet) {
    return new Promise((resolve, reject) => {
        const input = document.getElementById(inputId);
        if (!input || input.files.length === 0) { resolve([]); return; }
        const datos = new FormData();
        for (const f of input.files) datos.append('ficheros', f, f.name);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/subir');
        xhr.upload.onprogress = e => { if (e.lengthComputable) dotnet.invokeMethodAsync('Progreso', e.loaded, e.total); };
        xhr.onload = () => xhr.status === 200 ? resolve(JSON.parse(xhr.responseText)) : reject(xhr.responseText);
        xhr.onerror = () => reject('Error');
        xhr.send(datos);
    });
};
